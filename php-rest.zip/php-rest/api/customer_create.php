<?php
header('Access-Control-Allow-Origin: *');
header("Content-Type: application/json; charset=UTF-8");

require("../includes/conn_mysql.php");
require("../includes/customer_functions.php");

// Skapar databaskopplingen
$connection = dbConnect();

if(isset($_POST['customerName'])){
    $name = $_POST['customerName'];
}else{
    echo "Ingen tillåten post (customerName)";
    exit;
}
if(isset($_POST['customerEmail'])){
    $email = $_POST['customerEmail'];
}else{
    echo "Ingen tillåten post (customerEmail)";
    exit;
}
if(isset($_POST['customerPassword'])){
    $email = $_POST['customerPassword'];
}else{
    echo "Ingen tillåten post (customerPassword)";
    exit;
}

$saveCustomer = saveCustomer($connection);

if(isset($saveCustomer) && $saveCustomer > 0 ) {
    $customerData = getCustomerData($connection, $saveCustomer);

    $output = $customerData;

    echo json_encode($output);
}

// Stänger databaskopplingen
dbDisconnect($connection);
?>

