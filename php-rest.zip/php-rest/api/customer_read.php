<?php
header('Access-Control-Allow-Origin: *');
header("Content-Type: application/json; charset=UTF-8");

require("../includes/conn_mysql.php");
require("../includes/customer_functions.php");

// Skapar databaskopplingen
$connection = dbConnect();

if(isset($_GET['customerid']) && $_GET['customerid'] > 0 ){
    $customerData = getCustomerData($connection,$_GET['customerid']);
}else{
    echo "Inget giltligt ID";
}

$output = $customerData;

echo json_encode($output);

// Stänger databaskopplingen
dbDisconnect($connection);
?>
